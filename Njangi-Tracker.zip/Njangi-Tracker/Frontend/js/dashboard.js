(async () => {
  const me = await requireRole('admin');
  if (!me) return;
  userName.textContent = me.name;
  userAvatar.textContent = (me.name || 'NG').split(/\s+/).map(x => x[0]).slice(0, 2).join('').toUpperCase();
  logoutButton.onclick = logout;
  mobileMenu.onclick = () => { sidebar.classList.toggle('open'); sidebarOverlay.classList.toggle('show'); };

  const d = (await api('/dashboard')).data;
  const enrolled = d.members.filter(m => m.enrolled);

  totalPool.textContent = money(d.total_pool);
  totalMembers.textContent = d.members.length;
  activeCycleTarget.textContent = d.active_cycle ? `Target: ${money(d.active_cycle.target)}` : 'No active cycle';
  progressValue.textContent = d.progress + '%';
  progressAmountText.textContent = money(d.cycle_collected) + ' collected';
  collectedAmount.textContent = money(d.cycle_collected);
  cycleTargetAmount.textContent = money(d.active_cycle?.target || 0);
  progressFill.style.width = d.progress + '%';
  progressText.textContent = d.progress + '%';
  remainingAmount.textContent = money(Math.max((d.cycle_expected || 0) - d.cycle_collected, 0)) + ' remaining';
  cycleStartDate.textContent = d.active_cycle?.start_date ? fmtDate(d.active_cycle.start_date) : '-';
  membersPaid.textContent = `${d.members_paid} / ${enrolled.length}`;

  function renderMembers() {
    const q = (memberSearch.value || '').trim().toLowerCase();
    const list = (q ? d.members.filter(m => m.name.toLowerCase().includes(q)) : d.members).slice(0, 8);
    memberList.innerHTML = list.map(m => `<div class="member-row"><span>${esc(m.name)}</span><span>${money(m.paid)}</span><span class="status ${m.status.toLowerCase()}">${m.status}</span></div>`).join('')
      || '<div class="member-row"><span>No members found.</span></div>';
  }
  memberSearch.oninput = renderMembers;
  renderMembers();

  const cs = await api('/contributions');
  contributionTable.innerHTML = cs.contributions.slice(0, 8).map(p => `<tr><td>${esc(p.member_name)}</td><td>${money(p.amount)}</td><td>${fmtDate(p.date)}</td><td>${esc(p.status)}</td></tr>`).join('')
    || '<tr><td colspan="4" style="text-align:center;padding:20px">No payments recorded yet.</td></tr>';
  addContributionButton.onclick = () => location.href = 'contributions.html';
})().catch(e => alert(e.message));
